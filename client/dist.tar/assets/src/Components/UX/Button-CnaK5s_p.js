import{d as r}from"../../../vendor-DQyd_2nk.js";const e=r.button`
    background-color: blue;
    background: url(${o=>o.img})
    color: ${o=>o.error?"red":"white"};
    font-size: 20px;
`;export{e as M};
//# sourceMappingURL=Button-CnaK5s_p.js.map
