import{P as s,j as o}from"../../../vendor-DQyd_2nk.js";const t="_welcomeText_14bob_1",c={welcomeText:t},{welcomeText:m}=c,n=({namePeople:e})=>o.jsxs("h2",{className:m,children:["Bienvenue ",e]});n.propTypes={namePeople:s.string.isRequired};export{n as W};
//# sourceMappingURL=WelcomeMessage-CqxqMvQA.js.map
