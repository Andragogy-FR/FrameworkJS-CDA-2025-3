import{j as e}from"../../vendor-DQyd_2nk.js";function r(){return e.jsx(e.Fragment,{children:e.jsx("p",{children:"Welcome To My Life !"})})}export{r as W};
//# sourceMappingURL=WelcomeHome-9cxZkxty.js.map
